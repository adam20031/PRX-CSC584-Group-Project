package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ConfirmBookingServlet")
public class ConfirmRegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String username = request.getParameter("username");
        String user_fullname = request.getParameter("user_fullname");
        String user_gender = request.getParameter("user_gender");
        String user_number = request.getParameter("user_number");
        String user_password = request.getParameter("user_password");

        Connection con = null;
        PreparedStatement ps = null;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            String url = "jdbc:derby://localhost:1527/bookingcourt;create=true;user=app;password=app";

            con = DriverManager.getConnection(url);
            ps = con.prepareStatement("INSERT INTO GUEST(username, user_fullname, user_password, user_number, user_gender) VALUES(?, ?, ?, ?, ?)");

            ps.setString(1, username);
            ps.setString(2, user_fullname);
            ps.setString(3, user_password);
            ps.setString(4, user_number);
            ps.setString(5, user_gender);

            int statement = ps.executeUpdate();

            if (statement == 1) {
                HttpSession session = request.getSession();
                session.setAttribute("username", username);
                response.sendRedirect("Login.jsp");
            } else {
                response.getWriter().println("Error.. Data not in database!");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error.. Data not in database!");
        } finally {
            try {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
